INSERT INTO `estafacil`.`tipomovimentacao`
(`nometipo`)
VALUES ('ENTRADA');
INSERT INTO `estafacil`.`tipomovimentacao`
(`nometipo`)
VALUES ('SAÍDA');
INSERT INTO `estafacil`.`tipotarifaveiculo`
(`nometipo`,`tarifa`)
VALUES ('MOTO',4.00);
INSERT INTO `estafacil`.`tipotarifaveiculo`
(`nometipo`,`tarifa`)
VALUES ('PEQUENO',5.00);
INSERT INTO `estafacil`.`tipotarifaveiculo`
(`nometipo`,`tarifa`)
VALUES ('GRANDE',6.00);